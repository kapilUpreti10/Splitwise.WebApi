﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Splitwise.DataAccess.Migrations
{
    /// <inheritdoc />
    public partial class test : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "user-001");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "user-002");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "user-003");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "user-004");

            migrationBuilder.DeleteData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "user-005");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "AspNetUsers",
                columns: new[] { "Id", "AccessFailedCount", "Address", "ConcurrencyStamp", "CreatedAt", "Email", "EmailConfirmed", "LockoutEnabled", "LockoutEnd", "Name", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "TwoFactorEnabled", "UserName" },
                values: new object[,]
                {
                    { "user-001", 0, "Kathmandu", "dbbe6206-a3c8-4463-93c3-8b7f07595f59", new DateTime(2026, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "kapil@example.com", true, false, null, "Kapil Upreti", "KAPIL@EXAMPLE.COM", "KAPIL", "AQAAAAIAAYagAAAAEAZx6oWb1/m9EvmbWMcQZvQYteRtB4w2AqiaNoqO+Eqfc2x/mpr1Mk1S0A3OOxza0g==", null, false, "a91fcf5f-256b-42b9-8191-eaea17ebbab3", false, "kapil" },
                    { "user-002", 0, "Mahendranagar", "9773c83e-1a47-4a61-955b-11684b488d40", new DateTime(2026, 1, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), "niraj@example.com", true, false, null, "Niraj Karki", "NIRAJ@EXAMPLE.COM", "NIRAJ", "AQAAAAIAAYagAAAAEKbVcYcgbeTr5H12+wl7GsK3jhMTYnvxt7NYbGgSJRvbVbvvHJsgm29TLgKCkWarXw==", null, false, "2cc0035c-2f87-47f5-9eb0-c3b8c2142da6", false, "Niraj" },
                    { "user-003", 0, "Argakhanchi", "548a53c4-e15d-4d31-94d1-5bd8b94257aa", new DateTime(2026, 1, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), "pratap@example.com", true, false, null, "Pratap Kunwar", "PRATAP@EXAMPLE.COM", "PRATAP", "AQAAAAIAAYagAAAAEMVeU+XMblpEyNLe8wlsQwvZiR1twdlvhi//vM1XVb2eaRfX0uF8H3ti0NYsvHwRTA==", null, false, "da1a136d-c4f2-436a-b6f8-c8d4c108d689", false, "Pratap" },
                    { "user-004", 0, "Butwal", "ad35ce73-658b-45ee-a7bd-47483f0c9d1d", new DateTime(2026, 1, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), "pariskar@example.com", true, false, null, "Pariskar Poudel", "PARISKAR@EXAMPLE.COM", "PARISKAR", "AQAAAAIAAYagAAAAEPKhSgXj7sWfG0Iqhy++5f6LUicpWcMJuFGbRVWtBGajmFsUWZyJRDna4fuwEaDn5A==", null, false, "89556456-2222-422a-9fa5-fa799fdc3292", false, "Pariskar" },
                    { "user-005", 0, "Dang", "3c1f5c13-98c6-4780-af96-e30516eaffa6", new DateTime(2026, 1, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), "parbat@example.com", true, false, null, "Parbat Pandey", "PARBAT@EXAMPLE.COM", "PARBAT", "AQAAAAIAAYagAAAAEDc2EU4wGZbdZLQxbpdxc8HwLQV7u0foLPO71WpCv190whBUZnLAC01feheDq3RcRA==", null, false, "1392db60-2461-4a87-9642-3e15597dd5c3", false, "Parbat" }
                });
        }
    }
}
